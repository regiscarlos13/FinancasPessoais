$(document).ready(function() { $("#ano_ano").select2(); });
