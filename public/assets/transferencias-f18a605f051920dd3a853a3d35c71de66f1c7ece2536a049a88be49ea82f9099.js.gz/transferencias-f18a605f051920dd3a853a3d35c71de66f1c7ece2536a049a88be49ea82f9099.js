$(document).ready(function() {$("#pagamento_banco_id").select2({width: '100%'});});
$(document).ready(function() {$("#pagamento_transferencia_attributes_obs").select2({width: '100%'});});


