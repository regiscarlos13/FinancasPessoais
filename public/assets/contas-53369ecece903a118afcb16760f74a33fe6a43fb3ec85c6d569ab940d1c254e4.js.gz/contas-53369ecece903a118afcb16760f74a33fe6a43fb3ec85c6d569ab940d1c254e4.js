$(document).ready(function() { $("#conta_grupocont_id").select2({width: '100%'}); });
