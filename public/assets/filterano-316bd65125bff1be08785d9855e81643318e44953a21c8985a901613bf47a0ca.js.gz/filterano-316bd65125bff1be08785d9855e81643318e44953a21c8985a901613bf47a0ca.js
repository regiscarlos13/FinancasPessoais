	$(function () {
		$("#chk_janeiro").change(function() {
			if ($("#chk_janeiro").is(':checked')) {
				$("#janeiro").show();
			} else {
				$("#janeiro").hide();
			}
		});

		$("#chk_fevereiro").change(function() {
			if ($("#chk_fevereiro").is(':checked')) {
				$("#fevereiro").show();
			} else {
				$("#fevereiro").hide();
			}
		});
		$("#chk_marco").change(function() {
			if ($("#chk_marco").is(':checked')) {
				$("#marco").show();
			} else {
				$("#marco").hide();
			}
		});
		$("#chk_abril").change(function() {
			if ($("#chk_abril").is(':checked')) {
				$("#abril").show();
			} else {
				$("#abril").hide();
			}
		});
		$("#chk_maio").change(function() {
			if ($("#chk_maio").is(':checked')) {
				$("#maio").show();
			} else {
				$("#maio").hide();
			}
		});
		$("#chk_junho").change(function() {
			if ($("#chk_junho").is(':checked')) {
				$("#junho").show();
			} else {
				$("#junho").hide();
			}
		});
		$("#chk_julho").change(function() {
			if ($("#chk_julho").is(':checked')) {
				$("#julho").show();
			} else {
				$("#julho").hide();
			}
		});
		$("#chk_agosto").change(function() {
			if ($("#chk_agosto").is(':checked')) {
				$("#agosto").show();
			} else {
				$("#agosto").hide();
			}
		});
		$("#chk_setembro").change(function() {
			if ($("#chk_setembro").is(':checked')) {
				$("#setembro").show();
			} else {
				$("#setembro").hide();
			}
		});
		$("#chk_outubro").change(function() {
			if ($("#chk_outubro").is(':checked')) {
				$("#outubro").show();
			} else {
				$("#outubro").hide();
			}
		});
		$("#chk_novembro").change(function() {
			if ($("#chk_novembro").is(':checked')) {
				$("#novembro").show();
			} else {
				$("#novembro").hide();
			}
		});
		$("#chk_dezembro").change(function() {
			if ($("#chk_dezembro").is(':checked')) {
				$("#dezembro").show();
			} else {
				$("#dezembro").hide();
			}
		});
	});
