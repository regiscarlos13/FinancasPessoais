  function changeFunc() {
    var selectedValue = selectBox.options[selectBox.selectedIndex].value;
    $('#button').click();
  }
;
